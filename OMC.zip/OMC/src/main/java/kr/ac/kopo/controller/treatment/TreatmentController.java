package kr.ac.kopo.controller.treatment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.google.gson.Gson;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.boardReservation.service.BoardReservationService;
import kr.ac.kopo.boardReservation.service.ReservationService;
import kr.ac.kopo.boardReservation.vo.ReservationVO;
import kr.ac.kopo.controller.Controller;
import kr.ac.kopo.treatment.service.TreatmentService;
import kr.ac.kopo.treatment.service.TreatmentServiceImpl;
import kr.ac.kopo.treatment.vo.DoctorData;
import kr.ac.kopo.treatment.vo.TreatmentRoomStatusVO;
import kr.ac.kopo.user.service.UserService;
import kr.ac.kopo.user.service.UserServiceImpl;
import kr.ac.kopo.user.vo.UserVO;

public class TreatmentController implements Controller {

    private TreatmentService treatmentService;
    private ReservationService reservationService;
    private UserService userService;
    private Gson gson;
    
    public TreatmentController() {
        treatmentService = new TreatmentServiceImpl();
        reservationService = new BoardReservationService();
        userService = new UserServiceImpl();
        gson = new Gson();
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	
    	String action = request.getParameter("action");
    	if("getTreatmentRoomStatus".equals(action)) {
    		return getTreatmentRoomStatus(request, response);
    	}
        
    	SimpleDateFormat sdf1 = new SimpleDateFormat("EEEE", Locale.ENGLISH);
    	String today = sdf1.format(new Date());
    	System.out.println("오늘은 : " + today + " 입니다.");
        List<UserVO> doctorList = userService.getDoctorsByWorkDay(today);
        System.out.println("오늘 근무하는 의사목록 : " + doctorList.toString());
        if(doctorList.isEmpty()) {
        	System.out.println("근무하는 의사가 없습니다.");
        }
        // 세션에서 doctorReservationMap 가져오기 또는 초기화
        Map<String, DoctorData> doctorReservationMap = 
            (Map<String, DoctorData>) request.getSession().getAttribute("doctorReservationMap");
        
        if(doctorReservationMap == null) {
            doctorReservationMap = new HashMap<>();
            for(UserVO doctor : doctorList) {
                DoctorData doctorData = new DoctorData(doctor.getName());
                doctorReservationMap.put(doctor.getUserID(), doctorData);
            }
            request.getSession().setAttribute("doctorReservationMap", doctorReservationMap);
        }

        //오늘예약 가지고오기
        List<ReservationVO> todayReservation = treatmentService.searchTodayReservation();
        if(todayReservation.isEmpty()) {
        	System.out.println("오늘 예약된 환자가 없습니다.");
        }else {
            System.out.println("오늘 예약 목록 : " + todayReservation.toString());        	
        }

        
        for(ReservationVO reservation : todayReservation) {
        	String doctorUserID = reservation.getDoctorID();
        	if (doctorReservationMap.containsKey(doctorUserID)) {
                DoctorData doctorData = doctorReservationMap.get(doctorUserID);
                doctorData.getReservations().add(reservation);
            } else {
                System.out.println("해당 doctorID가 오늘 근무하는 의사 목록에 없습니다: " + doctorUserID);
            }
        }
        
        // 치료실 상태 가져오기
        List<TreatmentRoomStatusVO> treatmentRoomStatusList = treatmentService.getTreatmentRoomStatus();
        System.out.println("Total beds fetched: " + treatmentRoomStatusList.size());
        
        // 비어있는 침대 찾기
        List<TreatmentRoomStatusVO> emptyBeds = new ArrayList<>();
        for(TreatmentRoomStatusVO bed : treatmentRoomStatusList) { 
            if(bed == null) {
                System.out.println("Null bed encountered in treatmentRoomStatusList");
                continue;
            }
            System.out.println("Bed ID: " + bed.getBedID() + ", Status: " + bed.getBedStatus() + ", Number: " + bed.getBedNumber());
            if("empty".equalsIgnoreCase(bed.getBedStatus())) { 
                emptyBeds.add(bed);    
            }
        }
        System.out.println("Empty beds count: " + emptyBeds.size());
        
        // 예약과 침대 매핑 맵
        Map<Integer, TreatmentRoomStatusVO> reservationBedMap = 
            (Map<Integer, TreatmentRoomStatusVO>) request.getSession().getAttribute("reservationBedMap");
        
        if(reservationBedMap == null) {
            reservationBedMap = new HashMap<>();
        }
        
        // 예약을 비어있는 침대에 할당
        Iterator<TreatmentRoomStatusVO> bedIterator = emptyBeds.iterator();
        for(UserVO doctor : doctorList) {
            DoctorData doctorData = doctorReservationMap.get(doctor.getUserID());
            List<ReservationVO> reservations = doctorData.getReservations();
            if(reservations == null) {
                System.out.println("reservations is null for doctor: " + doctor.getUserID());
                continue;
            }
            for(ReservationVO reservation : reservations) {
                if("YES".equalsIgnoreCase(reservation.getStatus())) {
                    if(bedIterator.hasNext()) {
                        TreatmentRoomStatusVO bed = bedIterator.next();
                        if(bed == null) {
                            System.out.println("bed is null while assigning");
                            continue;
                        }
                        TreatmentRoomStatusVO assignedBed = treatmentService.assignedBedToReservation(reservation);
                        if(assignedBed != null) {
                        	reservationBedMap.put(reservation.getReservationID(), assignedBed);
                        }else {
                        	System.out.println("비어있는 침대가 없습니다. 예약ID:" + reservation.getReservationID());
                        }

                    } else {
                        // 비어있는 침대가 더 이상 없을 경우 처리 (예: 대기 목록에 추가)
                        // 필요 시 구현
                        System.out.println("더 이상 비어있는 침대가 없습니다.");
                    }
                }
            }
        }
        // 매핑 맵을 세션에 저장
        request.getSession().setAttribute("reservationBedMap", reservationBedMap);
        
        // 예약 상태 업데이트 (15분 경과 시 DONE)
        long currentTime = System.currentTimeMillis();
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");
        for(UserVO doctor : doctorList) {
            DoctorData doctorData = doctorReservationMap.get(doctor.getUserID());
            List<ReservationVO> reservations = doctorData.getReservations();
            if(reservations == null) {
                System.out.println("reservations is null for doctor: " + doctor.getUserID());
                continue;
            }
            for(ReservationVO reservation : reservations) {
                if(reservation.getReservationTime() != null) {
                    Date reservationDate = sdf2.parse(reservation.getReservationTime());
                    long reservationTime = reservationDate.getTime();
                    
                    if(currentTime - reservationTime >= 15 * 60 * 1000) { // 15분 경과
                        reservation.setStatus("DONE");
                        // 침대 상태 업데이트 (완료)
                        if(reservationBedMap.containsKey(reservation.getReservationID())) {
                            TreatmentRoomStatusVO bed = reservationBedMap.get(reservation.getReservationID());
                            if(bed != null) {
                                bed.setBedStatus("empty");
                                treatmentService.updateBedStatus(bed.getBedID(), "empty");
                            } else {
                                System.out.println("bed is null for reservationID: " + reservation.getReservationID());
                            }
                        }
                    }
                } else {
                    System.out.println("예약 시간 정보가 없습니다.");
                }
            }
        }
        
        // 의사 목록을 JSP로 전달
        request.setAttribute("doctorList", doctorList);
        
        // JSON 직렬화
        String todayReservationJson = gson.toJson(todayReservation);
        String reservationBedMapJson = gson.toJson(reservationBedMap);
        String doctorReservationMapJson = gson.toJson(doctorReservationMap);
        
        // JSP로 전달
        request.setAttribute("todayReservation", todayReservationJson);
        request.setAttribute("reservationBedMap", reservationBedMapJson);
        request.setAttribute("doctorReservationMapJson", doctorReservationMapJson);
        request.setAttribute("treatmentRoomStatusList", treatmentRoomStatusList);
        System.out.println("객체등록완료");
    
        return "/jsp/treatment/treatmentRoom.jsp"; // 기본 치료실 페이지 반환
    }
    
    private String getTreatmentRoomStatus(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 1. 현재 시간 기준으로 예약 상태 업데이트
        updateReservationStatuses();

        // 2. 현재 침대 상태 가져오기
        List<TreatmentRoomStatusVO> treatmentRoomStatusList = treatmentService.getTreatmentRoomStatus();

        // 3. 오늘의 예약 정보 가져오기
        List<ReservationVO> todayReservation = treatmentService.searchTodayReservation();

        // 4. 오늘 근무하는 의사 목록 가져오기
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE", Locale.ENGLISH); // 예: "Monday"
        String todayDayOfWeek = sdf.format(new Date());
        List<UserVO> doctorList = userService.getDoctorsByWorkDay(todayDayOfWeek);
        System.out.println("오늘 근무하는 의사 목록: " + doctorList.toString());

        // 5. 의사별 예약 매핑
        Map<String, DoctorData> doctorReservationMap = new HashMap<>();
        for (UserVO doctor : doctorList) {
            doctorReservationMap.put(doctor.getUserID(), new DoctorData(doctor.getName()));
        }

        for (ReservationVO reservation : todayReservation) {
            String doctorUserID = reservation.getDoctorID(); // doctor_id는 user_id로 가정
            if (doctorReservationMap.containsKey(doctorUserID)) {
                doctorReservationMap.get(doctorUserID).getReservations().add(reservation);
            }
        }

        // 6. 침대별 예약 매핑
        Map<Integer, TreatmentRoomStatusVO> reservationBedMap = new HashMap<>();
        List<TreatmentRoomStatusVO> emptyBeds = treatmentService.getEmptyBeds(); // 비어있는 침대 리스트 가져오기

        Iterator<TreatmentRoomStatusVO> bedIterator = emptyBeds.iterator();
        for(UserVO doctor : doctorList) {
            DoctorData doctorData = doctorReservationMap.get(doctor.getUserID());
            List<ReservationVO> reservations = doctorData.getReservations();
            if(reservations == null) {
                System.out.println("reservations is null for doctor: " + doctor.getUserID());
                continue;
            }
            for(ReservationVO reservation : reservations) {
                if("YES".equalsIgnoreCase(reservation.getStatus())) {
                    if(bedIterator.hasNext()) {
                        TreatmentRoomStatusVO bed = bedIterator.next();
                        if(bed == null) {
                            System.out.println("bed is null while assigning");
                            continue;
                        }
                        // 예약과 침대를 매핑
                        reservationBedMap.put(reservation.getReservationID(), bed);
                        // 침대 상태 업데이트 (진행 중)
                        bed.setBedStatus("ing");
                        // 침대 상태를 DB에 업데이트
                        treatmentService.updateBedStatus(bed.getBedID(), "ing");
                    } else {
                        // 비어있는 침대가 더 이상 없을 경우 처리 (예: 대기 목록에 추가)
                        System.out.println("더 이상 비어있는 침대가 없습니다.");
                    }
                }
            }
        }
        // 매핑 맵을 세션에 저장
        request.getSession().setAttribute("reservationBedMap", reservationBedMap);
        

        // 7. JSON 응답 준비
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("treatmentRoomStatusList", treatmentRoomStatusList);
        responseMap.put("doctorReservationMap", doctorReservationMap);
        responseMap.put("reservationBedMap", reservationBedMap);

        String jsonResponse = gson.toJson(responseMap);

        // 8. 응답 작성
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse);

        return null; // AJAX 요청이므로 페이지 리턴하지 않음
    }

    private void updateReservationStatuses() throws Exception {
        List<ReservationVO> reservations = reservationService.searchAllReservation();
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        for (ReservationVO reservation : reservations) {
            try {
                Date reservationDate = sdf.parse(reservation.getReservationTime());
                long diff = now.getTime() - reservationDate.getTime();
                if (diff >= 15 * 60 * 1000 && "YES".equalsIgnoreCase(reservation.getStatus())) {
                    // 15분이 지나고 상태가 'YES'인 경우 'DONE'으로 변경
                    reservationService.updateReservationStatus(reservation.getReservationID(), "DONE");
                    // 침대 상태 업데이트 (완료)
                    treatmentService.updateBedStatusByReservation(reservation.getReservationID(), "empty");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
