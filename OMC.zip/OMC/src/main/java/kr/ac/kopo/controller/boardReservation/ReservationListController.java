package kr.ac.kopo.controller.boardReservation;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.ac.kopo.boardReservation.service.BoardReservationService;
import kr.ac.kopo.boardReservation.service.ReservationService;
import kr.ac.kopo.boardReservation.vo.ReservationVO;
import kr.ac.kopo.controller.Controller;
import kr.ac.kopo.user.vo.UserVO;

public class ReservationListController implements Controller{

	private ReservationService reservationService;
	
	public ReservationListController() {
		reservationService = new BoardReservationService();
	}

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession session = request.getSession();
		UserVO loginVO = (UserVO) session.getAttribute("loginVO");
		if(loginVO == null) {
			List<ReservationVO> reservationList = reservationService.searchWeekReservation();
			request.setAttribute("reservationList", reservationList);
			return "/jsp/boardReservation/reservationList.jsp";
		}else {

			if(loginVO.getRoleID() == 1) {
				String userID = loginVO.getUserID();
				System.out.println("로그인된ID:"+userID);
				List<ReservationVO> reservationList = reservationService.searchMyReservation(userID);
				request.setAttribute("reservationMyList", reservationList);
				return "/jsp/boardReservation/reservationList.jsp";	
			}else {
				List<ReservationVO> reservationList = reservationService.searchAllReservation();
				request.setAttribute("reservationList", reservationList);
				return "/jsp/boardReservation/reservationList.jsp";
			}
		}
	}
}
