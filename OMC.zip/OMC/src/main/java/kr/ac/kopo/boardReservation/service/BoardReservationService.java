package kr.ac.kopo.boardReservation.service;

import java.util.List;

import kr.ac.kopo.boardReservation.dao.ReservationDAO;
import kr.ac.kopo.boardReservation.dao.ReservationDAOImpl;
import kr.ac.kopo.boardReservation.vo.ReservationVO;

public class BoardReservationService implements ReservationService{

	private ReservationDAO reservationDao;
	
	public BoardReservationService() {
		reservationDao = new ReservationDAOImpl();
	}
	
	@Override
	public List<ReservationVO> searchAllReservation() throws Exception {
		List<ReservationVO> reservationList = reservationDao.selectAllReservation();
		return reservationList;
	}
	
	@Override
	public List<ReservationVO> searchWeekReservation() throws Exception {
		List<ReservationVO> reservationList = reservationDao.selectWeekReservation();
		return reservationList;
	}

	@Override
	public ReservationVO searchReservationByReservationID(int reservationID) throws Exception {
		ReservationVO reservationVO = reservationDao.selectReservationByReservationID(reservationID);
		return reservationVO;
	}

	@Override
	public void addReservation(ReservationVO reservationVO) throws Exception {
		reservationDao.insertReservation(reservationVO);
	}

	@Override
	public List<ReservationVO> searchMyReservation(String userID) throws Exception {
		List<ReservationVO> reservationVO = reservationDao.selectMyReservation(userID);
		return reservationVO;
	}

	@Override
	public boolean checkReservationAvailability(String doctorID, String reservationTime) throws Exception {
		return reservationDao.isReservationAvailable(doctorID, reservationTime);
	}

	@Override
	public void updateReservationStatus(int reservationID, String status) throws Exception {
		reservationDao.updateReservationStatus(reservationID, status);
	}	
	
	
}
