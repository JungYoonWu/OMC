package kr.ac.kopo.boardQnA.service;

import java.util.List;

import kr.ac.kopo.boardQnA.dao.InquiryDAO;
import kr.ac.kopo.boardQnA.dao.InquiryDAOImpl;
import kr.ac.kopo.boardQnA.vo.InquiryVO;

public class BoardInquiryService implements InquiryService{

	private InquiryDAO inquiryDao;
	
	public BoardInquiryService () {
		inquiryDao = new InquiryDAOImpl();
	}
	
	@Override
	public List<InquiryVO> searchAllInquiry() throws Exception {
		List<InquiryVO> inquiryList = inquiryDao.selectAllInquiry();
		return inquiryList;
	}

	@Override
	public List<InquiryVO> searchAllInquiry(String userID) throws Exception {
		List<InquiryVO> inquiryList = inquiryDao.selectMyInquiry(userID);
		return inquiryList;
	}

	@Override
	public InquiryVO searchInquiryByUserID(String userID, int inquiryID) throws Exception {
		InquiryVO inquiryVO = inquiryDao.selectInquiryByUserID(userID, inquiryID);
		return inquiryVO;
	}

	@Override
	public void addInquiry(InquiryVO inquiryVO) throws Exception {
		inquiryDao.insertInquiry(inquiryVO);
	}
}
