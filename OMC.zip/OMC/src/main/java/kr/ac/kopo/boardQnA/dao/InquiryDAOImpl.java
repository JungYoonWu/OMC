package kr.ac.kopo.boardQnA.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import kr.ac.kopo.boardQnA.vo.InquiryVO;
import kr.ac.kopo.mybatis.MyConfig;

public class InquiryDAOImpl implements InquiryDAO{

	private SqlSession sqlSession;
	
	public InquiryDAOImpl() {
		sqlSession = new MyConfig().getInstance();
	}
	
	@Override
	public List<InquiryVO> selectAllInquiry() throws Exception {
		sqlSession.clearCache();
		List<InquiryVO> inquiryList = sqlSession.selectList("dao.InquiryDAO.selectAllInquiry");
		System.out.println(inquiryList.toString());
		return inquiryList;
	}
	
	@Override
	public List<InquiryVO> selectMyInquiry(String userID) throws Exception{
		sqlSession.clearCache();
		List<InquiryVO> inquiryList = sqlSession.selectList("dao.InquiryDAO.selectAllInquiry", userID);
		return inquiryList;
	}
	
	@Override
	public InquiryVO selectInquiryByUserID(String userID, int inquiryID) throws Exception {
		Map<String, Object> params = new HashMap<>();
		params.put("userID", userID);
		params.put("inquiryID", inquiryID);
		InquiryVO inquiryVO = sqlSession.selectOne("dao.InquiryDAO.selectInquiryByUserID", params);
		System.out.println("UserID : " + userID + "Inquiry : " + inquiryVO.toString());
		return inquiryVO;
	}

	@Override
	public List<InquiryVO> selectInquiryByStatus(String status) throws Exception {
		sqlSession.clearCache();
		List<InquiryVO> inquiryList = sqlSession.selectList("dao.InquiryDAO.selectInquiryByStatus",status);
		return inquiryList;
	}

	@Override
	public void insertInquiry(InquiryVO inquiryVO) throws Exception {
		try {
			sqlSession.insert("dao.InquiryDAO.insertInquiry", inquiryVO);
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			throw e;
		}
	}

	
}
