package kr.ac.kopo.treatment.service;

import java.util.List;

import kr.ac.kopo.boardReservation.dao.ReservationDAO;
import kr.ac.kopo.boardReservation.dao.ReservationDAOImpl;
import kr.ac.kopo.boardReservation.vo.ReservationVO;
import kr.ac.kopo.treatment.dao.TreatmentDAO;
import kr.ac.kopo.treatment.dao.TreatmentDAOImpl;
import kr.ac.kopo.treatment.vo.DoctorScheduleVO;
import kr.ac.kopo.treatment.vo.DoctorTimelineVO;
import kr.ac.kopo.treatment.vo.TreatmentRoomStatusVO;
import kr.ac.kopo.user.vo.DoctorVO;
import kr.ac.kopo.user.vo.UserVO;

public class TreatmentServiceImpl implements TreatmentService{

    private TreatmentDAO treatmentDao;
    private ReservationDAO reservationDao;

    public TreatmentServiceImpl() {
        treatmentDao = new TreatmentDAOImpl();
        reservationDao = new ReservationDAOImpl();
    }

    //
    public List<TreatmentRoomStatusVO> getTreatmentRoomStatus() throws Exception{
        // 치료실 상태 정보를 DB에서 가져오는 로직
        return treatmentDao.selectAllTreatmentRoomStatus();
    }

    public List<DoctorTimelineVO> getDoctorTimeline() throws Exception{
        // 한의사 타임라인을 DB에서 가져오는 로직
        return treatmentDao.getDoctorTimeline();
    }

	@Override
	public List<ReservationVO> searchTodayReservation() throws Exception {
		List<ReservationVO> todayReservation = treatmentDao.selectTodayReservation();
		return todayReservation;
	}

	@Override
	public void updateBedStatus(int bedID, String status) throws Exception {
		treatmentDao.updateBedStatus(bedID, status);
	}

	@Override
	public List<DoctorScheduleVO> getDoctorSchedule(int doctorID, String workDay) throws Exception {
		List<DoctorScheduleVO> doctorSchedule = treatmentDao.selectDoctorSchedule(doctorID, workDay);
		return doctorSchedule;
	}

	@Override
	public List<UserVO> getAllDoctors() throws Exception {
		return treatmentDao.selectAllDoctors();
	}

	@Override
	public List<DoctorVO> getOMDoctors() throws Exception {
		return treatmentDao.selectOMDoctors();
	}

	@Override
	public TreatmentRoomStatusVO assignedBedToReservation(ReservationVO reservation) throws Exception {
		TreatmentRoomStatusVO bed = treatmentDao.findEmptyBed();
		if(bed != null) {
			System.out.println("Assigning Bed ID: " + bed.getBedID() + " to Reservation ID: " + reservation.getReservationID());
			treatmentDao.updateBedStatus(bed.getBedID(), "ing");
			reservation.setBedID(bed.getBedID());
			reservationDao.updateReservationBedID(reservation.getReservationID(), bed.getBedID());
			reservationDao.updateReservationStatus(reservation.getReservationID(), "DONE");
			return bed;
		}
		System.out.println("No empty beds available for Reservation ID: " + reservation.getReservationID());
		return null; //비어있는 침대가 없는경우
	}

	@Override
	public void updateBedStatusByReservation(int reservationID, String status) throws Exception {
		int bedID = reservationDao.selectBedIDByReservationID(reservationID);
		if(bedID != 0) {
			treatmentDao.updateBedStatus(bedID, status);
		}
	}

	@Override
	public List<TreatmentRoomStatusVO> getEmptyBeds() throws Exception {
		return treatmentDao.getEmptyBeds();
	}
    
    
}
