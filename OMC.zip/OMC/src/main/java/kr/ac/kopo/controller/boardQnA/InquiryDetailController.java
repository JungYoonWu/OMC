package kr.ac.kopo.controller.boardQnA;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.boardQnA.service.BoardInquiryService;
import kr.ac.kopo.boardQnA.service.InquiryService;
import kr.ac.kopo.boardQnA.vo.InquiryVO;
import kr.ac.kopo.controller.Controller;

public class InquiryDetailController implements Controller {

	private InquiryService inquiryService;
	
	public InquiryDetailController() {
		inquiryService = new BoardInquiryService();
	}
	
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userID = request.getParameter("userID");
		System.out.println("파라미터로 전달받은 UserID:" + userID);
		int inquiryID = Integer.parseInt(request.getParameter("inquiryID"));
		System.out.println("파라미터로 전달받은 InquiryID:"+inquiryID);
		
		InquiryVO inquiryVO = inquiryService.searchInquiryByUserID(userID, inquiryID);
		request.setAttribute("inquiryVO", inquiryVO);
		
		return "/jsp/boardQnA/inquiryDetail.jsp";
	}

}
