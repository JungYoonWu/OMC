package kr.ac.kopo.controller.boardReservation;

public class FrontReservationController {

}
