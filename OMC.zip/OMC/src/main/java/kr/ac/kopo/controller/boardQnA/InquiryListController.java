package kr.ac.kopo.controller.boardQnA;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.ac.kopo.boardQnA.service.BoardInquiryService;
import kr.ac.kopo.boardQnA.service.InquiryService;
import kr.ac.kopo.boardQnA.vo.InquiryVO;
import kr.ac.kopo.controller.Controller;
import kr.ac.kopo.user.vo.UserVO;

public class InquiryListController implements Controller {

	private InquiryService inquiryService;
	
	public InquiryListController() {
		inquiryService = new BoardInquiryService();
	}
	
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession session = request.getSession();
		UserVO loginVO = (UserVO) session.getAttribute("loginVO");
		
		if(loginVO == null) {
			System.out.println("로그인된 사용자가 없습니다.");
			return "/jsp/boardQnA/inquiryList.jsp";
		}else {
			if(loginVO.getRoleID() == 1) {
				List<InquiryVO> inquiryList = inquiryService.searchAllInquiry(loginVO.getUserID());
				request.setAttribute("inquiryMyList", inquiryList);
				return "/jsp/boardQnA/inquiryList.jsp";
			}else {
				List<InquiryVO> inquiryList = inquiryService.searchAllInquiry();
				request.setAttribute("inquiryList", inquiryList);
				System.out.println(inquiryList.toString());
				return "/jsp/boardQnA/inquiryList.jsp";				
			}
		}

	}

}
