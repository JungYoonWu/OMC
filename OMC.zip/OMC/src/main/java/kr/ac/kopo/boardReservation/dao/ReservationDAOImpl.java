package kr.ac.kopo.boardReservation.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import kr.ac.kopo.boardReservation.vo.ReservationVO;
import kr.ac.kopo.mybatis.MyConfig;

public class ReservationDAOImpl implements ReservationDAO {

	private SqlSession sqlSession;
	
	public ReservationDAOImpl() {
		sqlSession = new MyConfig().getInstance();
	}
	
	@Override
	public List<ReservationVO> selectAllReservation() throws Exception {
		sqlSession.clearCache();
		List<ReservationVO> reservationList = sqlSession.selectList("dao.ReservationDAO.selectAllReservation");
		System.out.println(reservationList.toString());
		return reservationList;
	}

	@Override
	public ReservationVO selectReservationByReservationID(int reservationID) throws Exception {
		sqlSession.clearCache();
		ReservationVO reservationVO = sqlSession.selectOne("dao.ReservationDAO.selectReservationByReservationID",reservationID);
		if(reservationVO == null) {
				System.out.println("reservationVO is null");
		}else{System.out.println(reservationVO.toString());
		}
		return reservationVO;
	}

	@Override
	public List<ReservationVO> selectWeekReservation() throws Exception {
		sqlSession.clearCache();
		List<ReservationVO> reservationList = sqlSession.selectList("dao.ReservationDAO.selectWeekReservation");
		System.out.println(reservationList.toString());
		return reservationList;
	}

	@Override
	public void insertReservation(ReservationVO reservationVO) throws Exception {
		try {
			sqlSession.insert("dao.ReservationDAO.insertReservation", reservationVO);
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			throw e;
		}
	}

	@Override
	public List<ReservationVO> selectMyReservation(String userID) {
		sqlSession.clearCache();
		List<ReservationVO> reservationList = sqlSession.selectList("dao.ReservationDAO.selectMyReservation", userID);
		return reservationList;
	}

	@Override
	public boolean isReservationAvailable(String doctorID, String reservationTime) throws Exception {
		sqlSession.clearCache();
		Map<String, Object> params = new HashMap<>();
		params.put("doctorID", doctorID);
		params.put("reservationTime", reservationTime);
		int count = sqlSession.selectOne("dao.ReservationDAO.countReservations", params);
		return count == 0;
	}

	@Override
	public void updateReservationStatus(int reservationID, String status) throws Exception {
		sqlSession.clearCache();
		Map<String, Object> params = new HashMap<>();
		params.put("reservationID", reservationID);
		params.put("status", status);
		sqlSession.update("dao.ReservationDAO.updateReservationStatus", params);
		sqlSession.commit();
	}

	@Override
	public void updateReservationBedID(int reservationID, int bedID) throws Exception {
		sqlSession.clearCache();
		Map<String, Object> params = new HashMap<>();
		params.put("reservationID", reservationID);
		params.put("bedID", bedID);
		params.put("status", "DONE");
		sqlSession.update("dao.ReservationDAO.updateReservationBedID", params);
		sqlSession.commit();
	}

	@Override
	public int selectBedIDByReservationID(int reservationID) throws Exception {
		sqlSession.clearCache();
		Integer bedID = sqlSession.selectOne("dao.ReservationDAO.selectBedIDByReservationID", reservationID);
		return bedID != null ? bedID : 0;
	}
	
	
}
